## Copyright [2019]
## 
## Licensed under the Apache License, Version 2.0 (the "License");
## you may not use this file except in compliance with the License.
## You may obtain a copy of the License at
## 
##     http://www.apache.org/licenses/LICENSE-2.0
## 
## Unless required by applicable law or agreed to in writing, software
## distributed under the License is distributed on an "AS IS" BASIS,
## WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
## See the License for the specific language governing permissions and
## limitations under the License.
## 
## Permission must be obtained from the USC POSH project Maintainer to access 

## the original, unsanitized files. Please contact @USCPOSH or unglaub@usc.edu 

## for the necessary permissions.

## Private filename: [USC_65nm_SAR_ADC_Dec20_2018.tar.gz]